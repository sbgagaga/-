#ifndef _KSCAN_H_
#define _KSCAN_H_

#include "TypeDef.h"
#include <sc.h>
#include "AD.h"
#include "Display_lcd.h"
#include "global_variable.h"


void Kscan();
void Kdeal();
void Delay(uchar k);


#endif