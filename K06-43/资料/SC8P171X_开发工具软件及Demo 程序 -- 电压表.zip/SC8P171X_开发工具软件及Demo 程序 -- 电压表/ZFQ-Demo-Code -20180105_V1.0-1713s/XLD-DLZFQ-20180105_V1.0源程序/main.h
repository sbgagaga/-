#ifndef _MAIN_H_
#define _MAIN_H_
#include "TypeDef.h"
#include <sc.h>
#include "AD.h"
#include "Display_lcd.h"
#include "Kscan.h"
#include "global_variable.h"
/***************************************************
		I/O�ڶ���
***************************************************/

void PID_operation(void);
void PID_control(void);
void  Tmper_pro();
void Temp_setdeal();
#endif


