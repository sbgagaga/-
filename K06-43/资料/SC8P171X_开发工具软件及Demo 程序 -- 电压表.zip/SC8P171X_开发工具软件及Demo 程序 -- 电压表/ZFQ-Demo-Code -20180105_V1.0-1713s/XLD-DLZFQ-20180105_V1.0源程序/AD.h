#ifndef	_AD_H_
#define	_AD_H_
#include "TypeDef.h"
#include <sc.h>
#include "global_variable.h"

uchar Ad_sample(unsigned char adch);
void Ad_testing(unsigned char i);
void Check_Ntc();
void source_v(unsigned char i);


#endif