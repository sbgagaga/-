#ifndef _ADC_H_
#define _ADC_H_

#include <sc.h>
#include "main.h"
#include "display.h"
#include "mytype.h"


void Adc_v();
void Adc_f();
void Ad_deal();
void Adc_i();
void Ad_test();
void Ad_ini(uchar ADCH);
#endif