#ifndef	_common_H_
#define	_common_H_

//#include <string.h>
#include "TypeDef.h"
#include "global_var.h"
#include "sc.h"
#include "sc8p1711c.h"
#include "display.h"
#include "kscan.h"
#include "app_proc.h"

#endif