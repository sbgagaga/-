#ifndef ___AT_H_
#define ___AT_H_

#define __at(x) __attribute__((address(x)))

#endif
