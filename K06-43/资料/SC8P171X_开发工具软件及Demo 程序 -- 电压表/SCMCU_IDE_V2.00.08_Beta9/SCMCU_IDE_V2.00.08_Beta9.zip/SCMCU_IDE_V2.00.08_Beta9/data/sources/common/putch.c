/*
 * Function: putch
 * Weak implementation.  User implementation may be required
 */

void 
putch(char c)
{
}

