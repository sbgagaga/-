int isdig(int c)
{
	return((unsigned char)c >= '0' && (unsigned char)c <= '9');
}

