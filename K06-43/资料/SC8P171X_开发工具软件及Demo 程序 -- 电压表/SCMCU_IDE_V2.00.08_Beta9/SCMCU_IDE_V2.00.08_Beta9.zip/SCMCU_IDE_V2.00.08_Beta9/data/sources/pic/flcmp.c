
signed char
__flcmp(double a, double b)
{
	if(a < b)
		return -1;
	return a > b;
}
