#ifndef _Umul4_8_H
#define _Umul4_8_H

extern const unsigned char _U4_mul[16][16];

#define _Umul4_8(a, b) _U4_mul[a][b]

#endif/*_Umul4_8_H*/
