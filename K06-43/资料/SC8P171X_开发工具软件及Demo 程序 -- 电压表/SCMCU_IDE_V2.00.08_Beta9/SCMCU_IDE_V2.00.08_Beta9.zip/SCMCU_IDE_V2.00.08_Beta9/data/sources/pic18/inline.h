#ifdef __OPTIMIZE_SPEED__
#define _INLINE	__inline
#else
#define _INLINE
#endif
